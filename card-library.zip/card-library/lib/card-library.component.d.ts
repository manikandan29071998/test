import * as i0 from "@angular/core";
export declare class CardLibraryComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardLibraryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardLibraryComponent, "lib-card-library", never, {}, {}, never, never, false, never>;
}
