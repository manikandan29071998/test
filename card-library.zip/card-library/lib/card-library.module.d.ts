import * as i0 from "@angular/core";
import * as i1 from "./card-library.component";
export declare class CardLibraryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardLibraryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CardLibraryModule, [typeof i1.CardLibraryComponent], never, [typeof i1.CardLibraryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CardLibraryModule>;
}
