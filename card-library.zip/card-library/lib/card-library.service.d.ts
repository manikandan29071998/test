import * as i0 from "@angular/core";
export declare class CardLibraryService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CardLibraryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CardLibraryService>;
}
